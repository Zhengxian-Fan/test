import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import input from 'input';
import readline from 'readline';

import {
  CHECK_IF_DEV_SNIPE,
  CHECK_IF_MINTABLE_AND_FREEZABLE,
  CHECK_IF_PUMP_FUN_TOKEN,
  CHECK_IF_SOCIALS,
  CHECK_TOP10_HOLDERS_PERCENTAGE,
  ENABLE_RUG_CHECKS,
  MAX_SINGLE_OWNER_PERCENTAGE,
  MAX_TOP10_HOLDERS_PERCENTAGE,
  MIN_CURRENT_LIQUIDITY,
  MIN_SOL_LP,
  MIN_SOL_REQUIRED,
  MIN_TOKEN_LP_PERCENTAGE,
  logger,
  retrieveEnvVariable,
  sniperWallet,
  solanaConnection,
} from './constants';
import path from 'path';
import {
  checkSolBalance,
  initializeConfigurations,
  listenForTokenPurchase,
  logErrorToFile,
  storeData,
} from './utils';
import { StringSession } from 'telegram/sessions';
import { Api, TelegramClient } from 'telegram';
import { NewMessage, NewMessageEvent } from 'telegram/events';
import { ApiResponse, WebhookData } from './types';
import chalk from 'chalk';

const newDataPath = path.join(__dirname, 'sniper_data', 'bought_tokens.json');

const connection = solanaConnection;

const tgApiId = parseInt(retrieveEnvVariable('TG_API_ID', logger), 10);
const tgApiHash = retrieveEnvVariable('TG_API_HASH', logger);
const tgSessionId = process.env.TG_SESSION_ID || '';
const tgBotUsername = retrieveEnvVariable('TG_BOT_USERNAME', logger);

const botUsername = tgBotUsername;

const stringSession = new StringSession(tgSessionId); // fill this later with the value from session.save()

const client = new TelegramClient(stringSession, tgApiId, tgApiHash, {
  connectionRetries: 5,
  autoReconnect: true,
  retryDelay: 1000,
});

const app = express();
const port = 80;
//We are expecting the body to contain valid JSON from the Helius request
app.use(bodyParser.json());

app.post('/webhook', async (request: Request, response: Response) => {
  try {
    const incomingData = request.body;
    logger.info(`incoming data: ${JSON.stringify(incomingData, null, 2)}`);
    if (!incomingData) {
      logger.info(`No data received in webhook`);
      response.send('No data received');
      return;
    }

    //if no token address is present in the webhook data, return
    if (!incomingData?.data?.tokenAddress) {
      logger.info(`No token address present in webhook data. skipping...`);
      response.send('No token address present in webhook data. skipping...');
      return;
    }
    //You can now do whatever you want with the data
    const incomingWebhookData: ApiResponse = incomingData;

    await processWebhookData(incomingWebhookData.data);

    response.send('Received');
  } catch (error) {
    logger.error(`Error processing webhook data: ${error}`);
  }
});

async function processWebhookData(webhookData: WebhookData) {
  //You can now do whatever you want with the data
  const tokenAddress = webhookData?.tokenAddress;
  logger.info(`Processing webhook data for token ${tokenAddress}`);

  try {
    if (CHECK_IF_PUMP_FUN_TOKEN) {
      logger.info(`checking if pump fun token...`);
      //skip token if not a pump fun token
      if (!webhookData.isPumpFunToken) {
        logger.info(
          `Token ${tokenAddress} is not a pump fun token, skipping token`
        );
        return;
      }
    }
    if (ENABLE_RUG_CHECKS) {
      if (
        webhookData.initQuoteAmount < MIN_SOL_LP &&
        !webhookData.isPumpFunToken
      ) {
        logger.info(
          `Token ${tokenAddress} has less than ${MIN_SOL_LP} SOL in liquidity, skipping token`
        );
        return;
      }

      /**
       * CHECK LIQUIDITY LEVEL
       */

      if (webhookData.liquidity < MIN_CURRENT_LIQUIDITY) {
        logger.info(
          `Token ${tokenAddress} has less than ${MIN_CURRENT_LIQUIDITY} SOL in liquidity, skipping token`
        );
        return;
      }

      if (
        webhookData.initTokenSupplyPercent < MIN_TOKEN_LP_PERCENTAGE &&
        !webhookData.isPumpFunToken
      ) {
        logger.info(
          `Token ${tokenAddress} has less than ${MIN_TOKEN_LP_PERCENTAGE} % of the total supply in liquidity, skipping token`
        );
        return;
      }

      if (CHECK_IF_MINTABLE_AND_FREEZABLE) {
        if (webhookData.isMintable || webhookData.isFreezeable) {
          logger.info(
            `Token ${tokenAddress} is mintable or freezable, skipping token`
          );
          return;
        }
      }

      if (CHECK_TOP10_HOLDERS_PERCENTAGE) {
        if (webhookData.top10HoldersPercent > MAX_TOP10_HOLDERS_PERCENTAGE) {
          logger.info(
            `Token ${tokenAddress} has more than ${MAX_TOP10_HOLDERS_PERCENTAGE}% of the supply in the top 10 holders, skipping token`
          );
          return;
        }

        if (webhookData.topOwnersPercent > MAX_SINGLE_OWNER_PERCENTAGE) {
          logger.info(
            `Token ${tokenAddress} has a holder with ${MAX_SINGLE_OWNER_PERCENTAGE}% of the supply, skipping token`
          );
          return;
        }
      }

      if (CHECK_IF_SOCIALS) {
        if (!webhookData.socialsExists) {
          logger.info(
            `Token ${tokenAddress} does not have socials, skipping token`
          );
          return;
        }
      }

      if (CHECK_IF_DEV_SNIPE) {
        if (webhookData.devSniped) {
          logger.info(`Token ${tokenAddress} is sniped by dev, skipping token`);
          return;
        }
      }
    }

    logger.info(`checking sol balance...`);
    //check if wallet has sufficient funds
    const currentSolBalance = await checkSolBalance(connection, sniperWallet);

    if (currentSolBalance < MIN_SOL_REQUIRED) {
      const errMessage = `Insufficient sol balance in your wallet to trade. Required MIN_SOL_REQUIRED in your .env file: ${MIN_SOL_REQUIRED}, Available: ${currentSolBalance}`;
      logger.error(errMessage);
      return;
    }

    logger.info(
      `token address sent to tg bot for auto buy: ${webhookData.tokenAddress}}...`
    );

    const response = await client.sendMessage(botUsername, {
      message: webhookData.tokenAddress,
    });

    await listenForTokenPurchase(
      connection,
      webhookData.tokenAddress,
      sniperWallet,
      currentSolBalance
    );

    const newTokenData = {
      ...webhookData,
    };

    //store new tokens data in data folder
    await storeData(newDataPath, newTokenData);
  } catch (error) {
    const errMessage = `Error processing webhook data for ${tokenAddress}: ${error}`;
    logger.error(errMessage);
    logErrorToFile(errMessage, 'errorWebhookLogs.txt');
  }
}

// Start the Telegram client before the Express server
async function initializeServer() {
  try {
    await startTelegramClient();
    console.log(chalk.green('Telegram client initialized successfully.'));
    const bot = await client.getEntity(botUsername);

    const botId = bot.id;

    client.addEventHandler(
      (update: NewMessageEvent) => {
        const message = update.message.text;

        if (update.message.senderId.toString() === botId.toString()) {
          logger.info(`New message from bot: ${message}`);
        }
      },
      new NewMessage({
        chats: [botId, 'me'],
      })
    );

    await initializeConfigurations();
  } catch (error) {
    console.error('Failed to initialize Telegram client:', error);
    return; // Optionally halt the server start if Telegram client fails to start
  }

  // Start the Express server
  app.listen(port, () => {
    console.log(
      chalk.green(
        `\nServer running on port ${port}. listening for incoming webhooks...`
      )
    );
  });
}

initializeServer();

async function startTelegramClient() {
  logger.info('starting telegram client...');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  await client.start({
    phoneNumber: () =>
      new Promise((resolve) =>
        rl.question('Please enter your number (inc. country code): ', resolve)
      ),
    password: () =>
      new Promise((resolve) =>
        rl.question('Please enter your password: ', resolve)
      ),
    phoneCode: () =>
      new Promise((resolve) =>
        rl.question('Please enter the code you received in telegram: ', resolve)
      ),
    onError: (err) => console.log(err),
  });

  console.log('You should now be connected.');
  if (tgSessionId == '') {
    console.log(
      chalk.yellow(
        'Store this value in .env as TELEGRAM_SESSION_ID to avoid logging in again'
      )
    );
    console.log(client.session.save()); // Save this string to avoid logging in again
  }

  rl.close();
}
