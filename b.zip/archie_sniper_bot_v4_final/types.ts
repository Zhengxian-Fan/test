import { JsonMetadata } from '@metaplex-foundation/js';
import { VersionedTransaction } from '@solana/web3.js';

export type JitoBundle = {
  accepted: boolean;
  rejections: number;
  errorType: string | null;
  errorContent: string | null;
  landed: boolean;
  bundle: VersionedTransaction;
  signature?: string;
};

export interface MetadataInfo {
  name: string;
  symbol: string;
  sellerFeeBasisPoints: number;
  isMutable: boolean;
  json: JsonMetadata;
}

export type WebhookData = {
  burnTimestamp: string;
  creationTimestamp: string;
  creationSignature: string;
  tokenAddress: string;
  poolAddress: string;
  tokenSupply: number;
  burnPercentage: number;
  burnSignature: string;
  isTokenDangerous: boolean;
  isMintable: boolean;
  isFreezeable: boolean;
  isRenounced: boolean;
  isMutableInfo: boolean;
  creatorAddress: string;
  top10HoldersPercent: number;
  liquidity: number;
  thumbnailurl: string;
  creatorTokenPercent: number;
  socialsExists: boolean;
  socials: string | null;
  isPumpFunToken: boolean;
  riskAnalysis: string;
  initQuoteAmount: number | null;
  initTokenSupplyPercent: number | null;
  topOwnersPercent?: number | null;
  devSniped: boolean;
};

export type ApiResponse = {
  data: WebhookData;
};
