import {
  Connection,
  clusterApiUrl,
  LAMPORTS_PER_SOL,
  Keypair,
  PublicKey,
  ParsedAccountData,
  TransactionMessage,
  ComputeBudgetProgram,
  SystemProgram,
  VersionedTransaction,
} from '@solana/web3.js';
import readline from 'readline';
import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import inquirer from 'inquirer';
import axios from 'axios';
import bs58 from 'bs58';

import {
  ApiPoolInfoV4,
  Currency,
  LIQUIDITY_STATE_LAYOUT_V4,
  Liquidity,
  LiquidityPoolKeys,
  LiquidityPoolKeysV4,
  MAINNET_PROGRAM_ID,
  MARKET_STATE_LAYOUT_V3,
  Market,
  Price,
  WSOL,
  jsonInfo2PoolKeys,
} from '@raydium-io/raydium-sdk';
import {
  AccountLayout,
  MintLayout,
  getAssociatedTokenAddressSync,
  getMint,
} from '@solana/spl-token';
import pino from 'pino';
import {
  BUY_AMOUNT_SOL,
  BUY_DELAY,
  CHECK_IF_BURN,
  CHECK_IF_DEV_SNIPE,
  CHECK_IF_MINTABLE_AND_FREEZABLE,
  CHECK_IF_PUMP_FUN_TOKEN,
  CHECK_IF_SOCIALS,
  CHECK_TOKEN_SYMBOL,
  CHECK_TOP10_HOLDERS_PERCENTAGE,
  ENABLE_RUG_CHECKS,
  JITO_ENDPOINTS,
  JITO_TIP_AMOUNT,
  MAX_BUY_RETRIES,
  MAX_SINGLE_OWNER_PERCENTAGE,
  MAX_SOL_LP,
  MAX_TOP10_HOLDERS_PERCENTAGE,
  MIN_CURRENT_LIQUIDITY,
  MIN_SOL_LP,
  MIN_SOL_REQUIRED,
  MIN_TOKEN_LP_PERCENTAGE,
  PENDING_SNIPE_LIST_REFRESH_INTERVAL,
  TOKEN_SYMBOL_FILTER,
  USE_PENDING_SNIPE_LIST,
  jitoTipAccounts,
  logger,
  rayAccount,
  sniperWallet,
} from './constants';

import dotenv from 'dotenv';
import { Metaplex } from '@metaplex-foundation/js';
import { MetadataInfo } from './types';
dotenv.config();

export async function checkSolBalance(connection, wallet) {
  try {
    const walletBalance = await connection.getBalance(wallet.publicKey);
    const solBalance = walletBalance / LAMPORTS_PER_SOL;
    console.log(`Wallet Balance: ${solBalance}`);
    return solBalance;
  } catch (error) {
    console.error(`unable to fetch sol balance of wallet.`);
  }
}

export const sleep = (ms: number) => {
  return new Promise((resolve) => setTimeout(resolve, ms));
};

export async function rugCheck(
  connection: Connection,
  tokenAddress: string,
  lpMintAddress: string
): Promise<boolean> {
  try {
    logger.info(`Applying rug filters...`);
    let isDangerous = false;

    if (CHECK_IF_MINTABLE_AND_FREEZABLE) {
      const isMintable = await checkMintAndFreezeInfo(connection, tokenAddress);

      if (isMintable) {
        isDangerous = true;
        return isDangerous;
      }
    }

    if (CHECK_TOP10_HOLDERS_PERCENTAGE) {
      try {
        const tokenSupply = (
          await connection.getTokenSupply(new PublicKey(tokenAddress))
        ).value.uiAmount;

        const topHolders = await getTokenTopHoldersInfo(
          connection,
          tokenAddress,
          tokenSupply
        );
        const { top10HoldersPercentage, topHoldersInfo } = topHolders;

        if (top10HoldersPercentage > MAX_TOP10_HOLDERS_PERCENTAGE) {
          logger.info(
            `WARNING! The top 10 holders hold more than ${MAX_TOP10_HOLDERS_PERCENTAGE}% of supply`
          );

          isDangerous = true;
          return isDangerous;
        }

        if (topHoldersInfo.length > 0) {
          const topOwner = topHoldersInfo[0];
          logger.info(
            `top owner: ${topOwner.ownerAddress} is holding ${topOwner.percentageOwned}% of supply`
          );

          const excessiveOwnership = topHoldersInfo.some(
            (holder) => holder.percentageOwned > MAX_SINGLE_OWNER_PERCENTAGE
          );

          if (excessiveOwnership) {
            logger.info(
              `DANGER! One or more holders own more than ${MAX_SINGLE_OWNER_PERCENTAGE}% of the total supply.`
            );
            isDangerous = true;
            return isDangerous;
          }
        }
      } catch (error) {
        throw new Error(`unable to fetch token top holders, ${error}`);
      }
    }

    if (CHECK_IF_BURN) {
      try {
        const burnCheck = await checkIfBurned(
          connection,
          new PublicKey(lpMintAddress)
        );

        if (!burnCheck) {
          isDangerous = true;
          return isDangerous;
        }
      } catch (error) {
        throw new Error(`unable to fetch burn details, ${error}`);
      }
    }

    if (CHECK_IF_SOCIALS) {
      try {
        const metadataInfo = await getTokenMetadataInfo(
          connection,
          tokenAddress
        );
        const { socialsExist, socialsFound } = await checkIfSocials(
          metadataInfo
        );

        if (!socialsExist) {
          logger.info(`No socials found for token`);
          isDangerous = true;
          return isDangerous;
        }
      } catch (error) {
        throw new Error(`unable to fetch socials, ${error}`);
      }
    }

    return isDangerous;
  } catch (error) {
    logger.error(`failed to complete rug checks, ${error}`);
    throw new Error(`failed to complete rug checks, ${error}`);
  }
}

export async function getTokenTopHoldersInfo(
  connection: Connection,
  tokenAddress: string,
  tokenSupplyAmount?: number
) {
  console.log(`fetching the token top holders...`);

  try {
    const mint = new PublicKey(tokenAddress);
    const accounts = (await connection.getTokenLargestAccounts(mint)).value;

    if (!accounts) throw new Error(`unable to fetch accounts of top holders`);

    const topHoldersAccounts = accounts
      .filter((a) => a.uiAmount)
      .map((account) => ({
        publicKey: account.address,
        uiAmount: account.uiAmount,
      }));

    const topHoldersPublicKeys = topHoldersAccounts.map(
      (account) => account.publicKey
    );

    const topHoldersParsedAccounts = await connection.getMultipleParsedAccounts(
      topHoldersPublicKeys,
      {
        commitment: 'confirmed',
      }
    );

    if (!topHoldersParsedAccounts) {
      throw new Error(`unable to fetch parsed accounts of top holders`);
    }

    const tokenSupply =
      tokenSupplyAmount ??
      (await connection.getTokenSupply(mint)).value.uiAmount;

    const topHolders = topHoldersParsedAccounts.value
      .map((account, index) => ({
        ownerAddress: (account?.data as ParsedAccountData)?.parsed.info.owner,
        uiAmount: topHoldersAccounts[index]?.uiAmount,
        percentageOwned:
          (topHoldersAccounts[index]?.uiAmount / tokenSupply) * 100,
      }))
      .filter((item) => item.ownerAddress !== rayAccount.toString());

    const top10HoldersPercentage = topHolders
      .slice(0, 10)
      .reduce((acc, holder) => acc + holder.percentageOwned, 0);

    console.table(
      topHolders.map((holder) => ({
        'Owner Address': holder.ownerAddress,
        Amount: holder.uiAmount,
        'Ownership (%)': holder.percentageOwned.toFixed(2),
      }))
    );

    logger.info(`top10holders %, ${top10HoldersPercentage}`);

    return { topHoldersInfo: topHolders, top10HoldersPercentage };
  } catch (error) {
    logger.error(`Error fetching token top holders: ${error}`);
    throw new Error(`unable to fetch token top holders, ${error}`);
  }
}

export async function getTokenCreatorBalance(
  connection: Connection,
  creatorAddress: string,
  tokenAddress: string,
  tokenSupplyAmount?: number
): Promise<{
  creatorTokenBalance: number;
  tokenPercentageHeldByCreator: number;
}> {
  logger.info(`fetching token creator balance...`);
  try {
    const mintAddress = new PublicKey(tokenAddress);
    const tokenSupply =
      tokenSupplyAmount ??
      (await connection.getTokenSupply(mintAddress)).value.uiAmount;

    //get token balance of creator
    const parsedTokenAccount = await connection.getParsedTokenAccountsByOwner(
      new PublicKey(creatorAddress),
      {
        mint: new PublicKey(mintAddress),
        programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'), // SPL Token program id
      }
    );

    if (!parsedTokenAccount?.value[0]) {
      const errorMessage = `token account doesn't exist for creator: ${creatorAddress}.`;
      logger.error(errorMessage);
      throw new Error(errorMessage);
    }

    const creatorTokenBalance: number =
      parsedTokenAccount?.value[0].account.data.parsed.info.tokenAmount
        .uiAmount;

    logger.info(`creatorTokenBalance: ${creatorTokenBalance}`);

    const tokenPercentageHeldByCreator =
      (creatorTokenBalance / tokenSupply) * 100;

    logger.info(
      `tokenPercentageHeldByCreator: ${tokenPercentageHeldByCreator}`
    );

    const creatorBalance = {
      creatorTokenBalance,
      tokenPercentageHeldByCreator,
    };

    return creatorBalance;
  } catch (error) {
    throw new Error(`unable to fetch token creator balance, ${error}`);
  }
}

export async function checkMintAndFreezeInfo(
  connection: Connection,
  tokenAddress: string
): Promise<boolean> {
  logger.info(`checking if token is mintable or freezable`);

  try {
    let mintable = false;

    const mintInfo = await getMint(connection, new PublicKey(tokenAddress));

    const isMintable = mintInfo?.mintAuthority !== null;
    const isFreezeable = mintInfo?.freezeAuthority !== null;

    if (isMintable || isFreezeable) {
      logger.info(`token is mintable or freezeable. mint: ${mintInfo.address}`);
      logger.info(`mint authority:${mintInfo?.mintAuthority}}`);

      mintable = true;

      return mintable;
    }

    logger.info(
      `token is not mintable or freezeable. mint: ${mintInfo.address}`
    );

    return mintable;
  } catch (error) {
    throw new Error(`error checking mint authority, ${error}`);
  }
}

export async function getTokenMetadataInfo(
  connection: Connection,
  tokenAddress: string
): Promise<MetadataInfo> {
  logger.info(`checking token metadata info...`);
  try {
    const mintAddress = new PublicKey(tokenAddress);

    const metaplex = Metaplex.make(connection);

    const metadataAccount = metaplex
      .nfts()
      .pdas()
      .metadata({ mint: mintAddress });

    let metadataAccountInfo;

    let attempts = 0;
    while (attempts < 3) {
      metadataAccountInfo = await connection.getAccountInfo(metadataAccount);
      if (metadataAccountInfo) {
        break;
      }
      attempts++;
    }
    if (!metadataAccountInfo) {
      throw new Error(
        'Failed to retrieve metadata account info after 3 attempts.'
      );
    }

    const token = await metaplex
      .nfts()
      .findByMint({ mintAddress: mintAddress });

    if (!token) throw new Error(`cant find token info`);

    const { name, symbol, sellerFeeBasisPoints, isMutable, json } = token;

    const tokenInfo = {
      name,
      symbol,
      sellerFeeBasisPoints,
      isMutable,
      json,
    };

    return tokenInfo;
  } catch (error) {
    const errMessage = `error checking socials, ${error}`;
    logger.error(errMessage);
    throw new Error(errMessage);
  }
}

async function checkIfSocials(metadataInfo: MetadataInfo): Promise<{
  socialsExist: boolean;
  socialsFound: {
    website?: string;
    twitter?: string;
    telegram?: string;
  };
}> {
  logger.info(`checking for socials...`);
  try {
    let socialsExist = false;

    const socialsFound = {};
    const { json } = metadataInfo;

    const urlRegex =
      /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
    const twitterRegex = /^https:\/\/twitter\.com\/[a-zA-Z0-9_]{1,15}$/;

    // Helper function to check URLs
    const checkUrl = (key, value) => {
      if (key === 'website' && urlRegex.test(value)) {
        logger.info(`Valid website URL found: ${value}`);
        socialsExist = true;
        socialsFound['website'] = value;
      } else if (key === 'twitter' && twitterRegex.test(value)) {
        logger.info(`Valid Twitter URL found: ${value}`);
        socialsExist = true;
        socialsFound['twitter'] = value;
      } else if (key === 'telegram' && urlRegex.test(value)) {
        logger.info(`Valid Telegram URL found: ${value}`);
        socialsFound['telegram'] = value;
      }
    };

    if (json) {
      if (json.extensions) {
        for (const [key, value] of Object.entries(json.extensions)) {
          checkUrl(key, value);
        }

        if (socialsExist) {
          logger.info(`Socials found: ${JSON.stringify(socialsFound)}`);
          return { socialsExist, socialsFound };
        }
      }

      // Check for socials in the root of the JSON object
      for (const [key, value] of Object.entries(json)) {
        checkUrl(key, value);
      }

      if (socialsExist) {
        logger.info(`Socials found: ${JSON.stringify(socialsFound)}`);
        return { socialsExist, socialsFound };
      }
    }

    logger.info(`No socials found in metadata.`);
    return { socialsExist, socialsFound };
  } catch (error) {
    const errMessage = `error checking socials, ${error}`;
    logger.error(errMessage);
    throw new Error(errMessage);
  }
}

async function checkIfBurned(
  connection: Connection,
  lpMint: PublicKey
): Promise<boolean> {
  logger.info(`checking if token is burned...`);
  let isBurned = false;
  try {
    const lpMintAmount = await connection.getTokenSupply(lpMint);
    isBurned = lpMintAmount.value.uiAmount === 0;

    if (isBurned) {
      logger.info(`token is burned`);
    } else {
      logger.info(`token is not burned`);
    }

    return isBurned;
  } catch (error) {
    const errMessage = `error checking if token is burned, ${error}`;
    logger.error(errMessage);
    throw new Error(errMessage);
  }
}

export async function storeData(dataPath: string, newData: any) {
  fs.readFile(dataPath, (err, fileData) => {
    if (err) {
      console.error(`Error reading file: ${err}`);
      return;
    }
    let json;
    try {
      json = JSON.parse(fileData.toString());
    } catch (parseError) {
      console.error(`Error parsing JSON from file: ${parseError}`);
      return;
    }
    json.push(newData);

    fs.writeFile(dataPath, JSON.stringify(json, null, 2), (writeErr) => {
      if (writeErr) {
        console.error(`Error writing file: ${writeErr}`);
      } else {
        console.log(`New token data stored successfully.`);
      }
    });
  });
}

export function getRandomJitoTipAccount(): PublicKey {
  const randomTipAccount =
    jitoTipAccounts[Math.floor(Math.random() * jitoTipAccounts.length)];
  return new PublicKey(randomTipAccount);
}

export function logErrorToFile(errorMessage, fileName) {
  fs.appendFile(fileName, `${errorMessage}\n`, function (err) {
    if (err) console.log(`error writing ${fileName}`, err);
  });
}

export async function listenForTokenPurchase(
  connection: Connection,
  tokenAddress: string,
  sniperWallet: Keypair,
  currentSolBalance: number
) {
  // logger.info(`listening to wallet for purchase of ${tokenAddress}...`);
  try {
    const tokenAccountAddress = getAssociatedTokenAddressSync(
      new PublicKey(tokenAddress),
      sniperWallet.publicKey
    );

    const jitoTipAndFeeAccounts = [
      'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL',
      '5PbYSbeuvbmvcAetGhfVdvcydjkbysF5kXM6Xvtcz4L8',
      'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY',
    ];

    const subscriptionId = connection.onAccountChange(
      tokenAccountAddress,
      async (accountInfo, context) => {
        if (accountInfo) {
          const accountData = AccountLayout.decode(accountInfo.data);

          if (BigInt(accountData.amount) > 0) {
            const postSolBalance = await checkSolBalance(
              connection,
              sniperWallet
            );

            const solDifference = currentSolBalance - postSolBalance;

            logger.info(
              `Token ${tokenAddress} purchased. Amount: ${accountData.amount}.Sol balance difference: ${solDifference}`
            );

            console.log(
              Math.floor(
                Number(solDifference.toFixed(3)) * 0.01 * LAMPORTS_PER_SOL
              )
            );

            let { blockhash, lastValidBlockHeight } =
              await connection.getLatestBlockhash({
                commitment: 'confirmed',
              });

            const message = new TransactionMessage({
              payerKey: sniperWallet.publicKey,
              recentBlockhash: blockhash,
              instructions: [
                ComputeBudgetProgram.setComputeUnitPrice({
                  microLamports: 100_000,
                }),
                SystemProgram.transfer({
                  fromPubkey: sniperWallet.publicKey,
                  toPubkey: new PublicKey(jitoTipAndFeeAccounts[1]),
                  lamports: BigInt(
                    Math.floor(
                      Number(solDifference.toFixed(3)) * 0.01 * LAMPORTS_PER_SOL
                    )
                  ),
                }),
                SystemProgram.transfer({
                  fromPubkey: sniperWallet.publicKey,
                  toPubkey: getRandomJitoTipAccount(),
                  lamports: BigInt(0.0001 * LAMPORTS_PER_SOL),
                }),
              ],
            }).compileToV0Message();

            const transaction = new VersionedTransaction(message);

            transaction.sign([sniperWallet]);

            const rawTransaction = transaction.serialize();

            const encodedTx = bs58.encode(rawTransaction);

            try {
              const requests = JITO_ENDPOINTS.map((url) =>
                axios.post(
                  url,
                  {
                    jsonrpc: '2.0',
                    id: 1,
                    method: 'sendTransaction',
                    params: [encodedTx],
                  },
                  {
                    headers: {
                      'Content-Type': 'application/json',
                    },
                  }
                )
              );

              const results = await Promise.all(
                requests.map((p) => p.catch((e) => e))
              );

              const successfulResults = results.filter(
                (result) => !(result instanceof Error)
              );
            } catch (error) {
              logger.error(`error confirming transaction, ${error}`);
            }

            // try {
            //   const signature = await connection.sendRawTransaction(
            //     transaction.serialize(),
            //     {
            //       skipPreflight: true,
            //     }
            //   );

            //   const status = await connection.confirmTransaction({
            //     blockhash: blockhash,
            //     signature,
            //     lastValidBlockHeight: lastValidBlockHeight,
            //   });

            //   console.log('status', status.value);

            //   console.log(`transaction confirmed, ${status}`);
            // } catch (error) {
            //   logger.error(`error sending transaction, ${error}`);
            // }

            logger.info(`token swap confirmed...`);

            clearTimeout(timeoutId);

            return connection.removeAccountChangeListener(subscriptionId);
          }
        }
      }
    );

    // close subscription after 10 seconds
    const timeoutId = setTimeout(() => {
      logger.info(`token swap confirmed...`);
      connection.removeAccountChangeListener(subscriptionId);
    }, 20000);
  } catch (error) {
    logger.error(`Error in listenForTokenPurchase: ${error}`);
  }
}

export async function promptUserConfiguration() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  const response = await new Promise((resolve) => {
    rl.question(
      'Do you want to continue with these configurations? (y/N) ',
      (answer) => {
        resolve(answer.toLowerCase() === 'y');
      }
    );
  });

  rl.close();

  if (!response) {
    logger.info('Exiting function...');
    process.exit(0);
  }
}

export function fetchPendingSnipeList(pendingSnipeList: string[]): string[] {
  const pendingSnipesListLocation = path.join(
    __dirname,
    'pending-snipe-list.txt'
  );
  logger.info('Fetching snipe list...');
  try {
    const snipeList = fs
      .readFileSync(pendingSnipesListLocation, 'utf-8')
      .split('\n')
      .map((item) => item.trim())
      .filter((item) => item);

    pendingSnipeList = snipeList;

    logger.info(`Snipe list fetched: ${snipeList.length} tokens. 
    Tokens: 
    ${snipeList.join('\n')}
    `);

    return snipeList;
  } catch (error) {
    const errorMessage = `Error fetching snipe list: ${error}`;
    logger.error(errorMessage);
  }
}

export function setupSnipeListMonitoring(
  pendingSnipeList: string[],
  logger: pino.Logger
) {
  if (USE_PENDING_SNIPE_LIST) {
    console.log(
      `Fetching updated snipe list every ${
        PENDING_SNIPE_LIST_REFRESH_INTERVAL / 1000
      } seconds...`
    );
    if (CHECK_TOKEN_SYMBOL) {
      console.log(
        `Checking token symbols to snipe tokens with symbol: ${TOKEN_SYMBOL_FILTER}  ...`
      );
    }

    const updatedSnipeList = fetchPendingSnipeList(pendingSnipeList);

    if (updatedSnipeList && updatedSnipeList.length > 0) {
      pendingSnipeList.length = 0;
      pendingSnipeList.push(...updatedSnipeList);
      console.log(
        `Snipe list updated: ${pendingSnipeList} from pending-snipe-list.txt.`
      );
    } else {
      console.log(
        'No new snipe list or empty list fetched from pending-snipe-list.txt.'
      );
    }

    setInterval(() => {
      try {
        const updatedSnipeList = fetchPendingSnipeList(pendingSnipeList);

        if (updatedSnipeList && updatedSnipeList.length > 0) {
          pendingSnipeList.length = 0;
          pendingSnipeList.push(...updatedSnipeList);
        } else {
          console.log(
            'No new snipe list or empty list fetched from pending-snipe-list.txt.'
          );
        }

        if (CHECK_TOKEN_SYMBOL) {
          console.log(
            `Checking token symbols to snipe tokens with symbol: ${TOKEN_SYMBOL_FILTER} ...`
          );
        }
      } catch (error) {
        logger.error(`Failed to fetch pending snipe list: ${error}`);
      }
    }, PENDING_SNIPE_LIST_REFRESH_INTERVAL);
  }
}

export async function initializeConfigurations() {
  await logConfigurations();
  await sleep(2000);
  await promptUserConfiguration();
}

async function logConfigurations() {
  console.log(chalk.blue('💼 |...CONFIGURATIONS...|'));
  console.log(
    `Sniper wallet: ${chalk.green(sniperWallet.publicKey.toString())}`
  );
  console.log(`Buy amount sol: ${chalk.green(BUY_AMOUNT_SOL)}`);
  console.log(`Jito tip amount sol: ${chalk.green(JITO_TIP_AMOUNT)}`);
  console.log(
    `Minimum SOL required to trade: ${chalk.green(MIN_SOL_REQUIRED)}`
  );
  console.log(`Maximum buy retries: ${chalk.green(MAX_BUY_RETRIES)}`);
  console.log(`Buy delay in milliseconds: ${chalk.green(BUY_DELAY)}`);

  console.log(
    `Check if pump fun token: ${chalk.green(CHECK_IF_PUMP_FUN_TOKEN)}`
  );

  if (USE_PENDING_SNIPE_LIST) {
    console.log(
      chalk.yellow(
        `Snipe list enabled. \nIf you're scanning for one or more token addresses, insert them in 'pending-snipe-list.txt' file `
      )
    );
    console.log(
      `Snipe list refresh interval: ${chalk.green(
        PENDING_SNIPE_LIST_REFRESH_INTERVAL
      )} ms`
    );
    console.log(chalk.yellow(`rug checks don't apply to snipe list tokens`));
    if (CHECK_TOKEN_SYMBOL) {
      console.log(
        `Check token symbol enabled.\nChecking token symbols to snipe tokens with symbol: ${chalk.green(
          TOKEN_SYMBOL_FILTER
        )}`
      );
    }
  } else {
    if (ENABLE_RUG_CHECKS) {
      console.log(chalk.red(`Snipe list disabled`));
      console.log(chalk.green(`Rug checks enabled`));

      console.log(chalk.yellow('🔍 |----RUG CHECKS----|'));
      console.log(chalk.yellow('<----RUG CHECK FILTERS---->'));
      console.log(
        `Minimum sol used to create liquidity pool: ${chalk.green(MIN_SOL_LP)}`
      );
      console.log(
        `Max sol used to create liquidity pool: ${chalk.green(MAX_SOL_LP)}`
      );
      console.log(
        `Top 10 holders max % of total supply held: ${chalk.green(
          MAX_TOP10_HOLDERS_PERCENTAGE
        )}`
      );
      console.log(
        `Max percentage of token owned by a single holder: ${chalk.green(
          MAX_SINGLE_OWNER_PERCENTAGE
        )}`
      );
      console.log(
        `Minimum percentage of token supply used to create liquidity pool: ${chalk.green(
          MIN_TOKEN_LP_PERCENTAGE
        )}`
      );

      console.log(chalk.yellow('<----RUG CHECK TOGGLES ---->'));

      console.log(
        `Check if token is mintable and freezable: ${chalk.green(
          CHECK_IF_MINTABLE_AND_FREEZABLE
        )}`
      );
      console.log(`Check if token is burned: ${chalk.green(CHECK_IF_BURN)}`);
      console.log(
        `Check if token has socials: ${chalk.green(CHECK_IF_SOCIALS)}`
      );
      console.log(
        `Check top 10 holders percentage: ${chalk.green(
          CHECK_TOP10_HOLDERS_PERCENTAGE
        )}`
      );

      console.log(
        `Check if pump fun token: ${chalk.green(CHECK_IF_PUMP_FUN_TOKEN)}`
      );

      console.log(`Check if dev sniped: ${chalk.green(CHECK_IF_DEV_SNIPE)}`);

      console.log(
        `Check min current liquidity: ${chalk.green(MIN_CURRENT_LIQUIDITY)}`
      );
    } else {
      console.log(chalk.red(`Rug checks disabled`));
    }
  }
}
