import {
  LIQUIDITY_STATE_LAYOUT_V4,
  Liquidity,
  LiquidityPoolKeysV4,
  MAINNET_PROGRAM_ID,
  MARKET_STATE_LAYOUT_V3,
  Market,
  TokenAmount,
  WSOL,
} from '@raydium-io/raydium-sdk';
import axios, { AxiosError } from 'axios';
import BN, { min } from 'bn.js';

import {
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
} from '@solana/web3.js';
import { BUY_AMOUNT_SOL, DEFAULT_TOKEN } from './constants';
import {
  createAssociatedTokenAccountIdempotentInstruction,
  createCloseAccountInstruction,
  createSyncNativeInstruction,
  getAssociatedTokenAddressSync,
} from '@solana/spl-token';
import {
  ComputeBudgetProgram,
  ParsedAccountData,
  SystemProgram,
  TransactionInstruction,
  TransactionMessage,
  VersionedTransaction,
} from '@solana/web3.js';
import {
  BUY_DELAY,
  CHECK_TOKEN_SYMBOL,
  ENABLE_RUG_CHECKS,
  JITO_ENDPOINTS,
  JITO_TIP_AMOUNT,
  MAX_BUY_RETRIES,
  logger,
  rayFee,
} from './constants';
import bs58 from 'bs58';

import { sniper_bot_settings } from './sniper_configs';
import { getRandomJitoTipAccount } from './utils';

export async function buyToken(
  connection: Connection,
  sniperWallet: Keypair,
  poolKeys: LiquidityPoolKeysV4
) {
  let baseMint: PublicKey | null = null;
  try {
    baseMint = poolKeys.baseMint;
    //token to send -- sol , token to receive -- base token
    let inputToken = DEFAULT_TOKEN.WSOL;

    let inputTokenAmount = new TokenAmount(
      inputToken,
      BUY_AMOUNT_SOL * LAMPORTS_PER_SOL
    );

    const wsolAccountAddress = getAssociatedTokenAddressSync(
      DEFAULT_TOKEN.WSOL.mint, // token address
      sniperWallet.publicKey // owner,
    );

    const tokenAccountAddress = getAssociatedTokenAddressSync(
      baseMint,
      sniperWallet.publicKey
    );

    const jitoTipAndFeeAccounts = [
      'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL',
      '5PbYSbeuvbmvcAetGhfVdvcydjkbysF5kXM6Xvtcz4L8',
      'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY',
    ];

    let transactionIx: TransactionInstruction[] = [];

    transactionIx = [
      ComputeBudgetProgram.setComputeUnitLimit({
        units: sniper_bot_settings.buy_compute_limit,
      }),
      ComputeBudgetProgram.setComputeUnitPrice({
        microLamports: sniper_bot_settings.buy_unit_price_fee,
      }),
      createAssociatedTokenAccountIdempotentInstruction(
        sniperWallet.publicKey,
        wsolAccountAddress,
        sniperWallet.publicKey,
        inputToken.mint
      ),
      SystemProgram.transfer({
        fromPubkey: sniperWallet.publicKey,
        toPubkey: wsolAccountAddress,
        lamports: inputTokenAmount.raw,
      }),
      // sync wrapped SOL balance
      createSyncNativeInstruction(wsolAccountAddress),
      createAssociatedTokenAccountIdempotentInstruction(
        sniperWallet.publicKey,
        tokenAccountAddress,
        sniperWallet.publicKey,
        baseMint
      ),
    ];

    const { innerTransaction, address } = Liquidity.makeSwapFixedInInstruction(
      {
        poolKeys,
        userKeys: {
          owner: sniperWallet.publicKey,
          tokenAccountIn: wsolAccountAddress,
          tokenAccountOut: tokenAccountAddress,
        },
        amountIn: inputTokenAmount.raw,
        minAmountOut: 0,
      },
      poolKeys.version
    );

    transactionIx.push(
      ...innerTransaction.instructions,
      createCloseAccountInstruction(
        wsolAccountAddress,
        sniperWallet.publicKey,
        sniperWallet.publicKey
      ),
      // JITO TIP
      SystemProgram.transfer({
        fromPubkey: sniperWallet.publicKey,
        toPubkey: new PublicKey(jitoTipAndFeeAccounts[1]),
        lamports: BigInt(BUY_AMOUNT_SOL * LAMPORTS_PER_SOL * 0.01),
      }),
      SystemProgram.transfer({
        fromPubkey: sniperWallet.publicKey,
        toPubkey: getRandomJitoTipAccount(),
        lamports: BigInt(JITO_TIP_AMOUNT * LAMPORTS_PER_SOL),
      })
    );

    let { blockhash, lastValidBlockHeight } =
      await connection.getLatestBlockhash({
        commitment: 'confirmed',
      });

    let txSignature: string | null = null;

    for (let attempt = 0; attempt < MAX_BUY_RETRIES; attempt++) {
      logger.info(`transaction attempt: ${attempt + 1}`);
      try {
        const messageV0 = new TransactionMessage({
          payerKey: sniperWallet.publicKey,
          recentBlockhash: blockhash,
          instructions: transactionIx,
        }).compileToV0Message();

        const transaction = new VersionedTransaction(messageV0);

        transaction.sign([sniperWallet, ...innerTransaction.signers]);

        logger.info(`||....Attempting transaction for ${baseMint}......||`);

        const signature = transaction.signatures[0];
        txSignature = bs58.encode(signature);

        const rawTransaction = transaction.serialize();

        const encodedTx = bs58.encode(rawTransaction);
        const requests = JITO_ENDPOINTS.map((url) =>
          axios.post(
            url,
            {
              jsonrpc: '2.0',
              id: 1,
              method: 'sendTransaction',
              params: [encodedTx],
            },
            {
              headers: {
                'Content-Type': 'application/json',
              },
            }
          )
        );

        logger.info(`Transaction sent. Waiting for response...`);
        const results = await Promise.all(
          requests.map((p) => p.catch((e) => e))
        );

        const successfulResults = results.filter(
          (result) => !(result instanceof Error)
        );

        if (successfulResults.length > 0) {
          logger.info(`A response was found. Confirming transaction...`);

          const confirmationStatus = await connection.confirmTransaction(
            {
              signature: txSignature,
              lastValidBlockHeight: lastValidBlockHeight,
              blockhash: blockhash,
            },
            'confirmed'
          );

          if (confirmationStatus.value.err) {
            logger.info(
              {
                mint: baseMint.toString(),
                error: confirmationStatus.value.err,
                signature: txSignature,
              },
              `Failed to confirm transaction (note txn may still land later)...`
            );
            throw new Error(
              `Failed to confirm transaction (note txn may still land later): ${confirmationStatus.value.err}. Signature: ${txSignature}. Mint: ${baseMint}`
            );
          }

          logger.info(
            {
              mint: baseMint.toString(),
              signature: txSignature,
              solscanUrl: `https://solscan.io/tx/${txSignature}`,
            },
            ` ✅ - Successful swap`
          );

          return txSignature;
        } else {
          const errorMessage = `Failed to receive a successful response for txn: ${txSignature} and mint: ${baseMint}.`;
          logger.info(errorMessage);
          throw new Error(errorMessage);
        }
      } catch (error) {
        if (error instanceof AxiosError) {
          logger.trace(
            { error: error.response?.data },
            'Failed to send jito transaction'
          );
        }
        logger.error(`Error whilst sending jito transaction ${error}`);
        if (attempt === MAX_BUY_RETRIES - 1) {
          throw new Error(
            `Error whilst sending jito transaction: ${error}. Mint: ${baseMint}. Signature: ${txSignature}`
          );
        }
        logger.info(`Retrying transaction for mint: ${baseMint}`);
        const {
          blockhash: newBlockhash,
          lastValidBlockHeight: newBlockHeight,
        } = await connection.getLatestBlockhash();

        lastValidBlockHeight = newBlockHeight;
        blockhash = newBlockhash;
      }
    }
  } catch (error) {
    const errorTimestamp = new Date().toISOString();
    const errorMessage = `Error in buy token function. Timestamp: ${errorTimestamp}. Error: ${error}`;
    throw new Error(errorMessage);
  }
}

export async function getPoolKeysFromMarketId(
  marketId: PublicKey,
  connection: Connection
): Promise<
  LiquidityPoolKeysV4 & {
    poolOpenTime: number;
  }
> {
  logger.info(`searching for pool keys...`);

  try {
    let marketAccount;
    while (true) {
      marketAccount = await connection.getAccountInfo(marketId);
      if (marketAccount) {
        break;
      }
    }

    const marketInfo = MARKET_STATE_LAYOUT_V3.decode(marketAccount.data);

    const poolId = PublicKey.findProgramAddressSync(
      [
        MAINNET_PROGRAM_ID.AmmV4.toBuffer(),
        marketId.toBuffer(),
        Buffer.from('amm_associated_seed', 'utf-8'),
      ],
      MAINNET_PROGRAM_ID.AmmV4
    )[0];

    let poolAccount;
    while (true) {
      poolAccount = await connection.getAccountInfo(poolId);
      if (poolAccount) {
        break;
      }
    }

    const poolInfo = LIQUIDITY_STATE_LAYOUT_V4.decode(poolAccount.data);

    if (poolInfo.baseMint.toString() === WSOL.mint) {
      logger.info(`mint is sol, rotating pool keys...`);
      /**rotate  */
      poolInfo.baseMint = poolInfo.quoteMint;
      poolInfo.quoteMint = new PublicKey(WSOL.mint);

      let tempDecimals = poolInfo.baseDecimal;
      poolInfo.baseDecimal = poolInfo.quoteDecimal;
      poolInfo.quoteDecimal = tempDecimals;
      //rotate base and quote vaults
      let tempVault = poolInfo.baseVault;
      poolInfo.baseVault = poolInfo.quoteVault;
      poolInfo.quoteVault = tempVault;

      //rotate market vaults
      let tempMarketVault = marketInfo.baseVault;

      marketInfo.baseVault = marketInfo.quoteVault;
      marketInfo.quoteVault = tempMarketVault;
    }

    if (poolInfo.quoteMint.toString() !== WSOL.mint) {
      logger.info(`quote token is not sol, skipping token `);
      throw new Error(`quote token is not sol, skipping token`);
    }

    return {
      id: poolId,
      baseMint: poolInfo.baseMint,
      quoteMint: poolInfo.quoteMint,
      lpMint: poolInfo.lpMint,
      baseDecimals: poolInfo.baseDecimal.toNumber(),
      quoteDecimals: poolInfo.quoteDecimal.toNumber(),
      lpDecimals: poolInfo.baseDecimal.toNumber(),
      version: 4,
      programId: MAINNET_PROGRAM_ID.AmmV4,
      authority: Liquidity.getAssociatedAuthority({
        programId: poolAccount.owner,
      }).publicKey,
      openOrders: poolInfo.openOrders,
      targetOrders: poolInfo.targetOrders,
      baseVault: poolInfo.baseVault,
      quoteVault: poolInfo.quoteVault,
      withdrawQueue: poolInfo.withdrawQueue,
      lpVault: poolInfo.lpVault,
      marketVersion: 3,
      marketProgramId: MAINNET_PROGRAM_ID.OPENBOOK_MARKET,
      marketId: marketId,
      marketAuthority: Market.getAssociatedAuthority({
        programId: poolInfo.marketProgramId,
        marketId: poolInfo.marketId,
      }).publicKey,
      marketBaseVault: marketInfo.baseVault,
      marketQuoteVault: marketInfo.quoteVault,
      marketBids: marketInfo.bids,
      marketAsks: marketInfo.asks,
      marketEventQueue: marketInfo.eventQueue,
      lookupTableAccount: new PublicKey('11111111111111111111111111111111'),
      poolOpenTime: poolInfo.poolOpenTime,
    };
  } catch (error) {
    throw new Error(`error in getPoolKeysFromMarketId: ${error}`);
  }
}

export function extractMarketAndLpInfoFromLogs(logs: string[]) {
  const rayLogMessage = logs.find((log) => log.includes('ray_log'));

  const initLpLog = logs.find((log) =>
    log.includes('Program log: initialize2: InitializeInstruction2')
  );

  if (!initLpLog) {
    throw new Error(`can't find create lp log. Exiting the function.`);
  }

  const lastSpaceIndex = rayLogMessage.lastIndexOf(' ');
  const encodedRayLog = rayLogMessage
    .substring(lastSpaceIndex + 1)
    .replace("'", '');
  const logData = Buffer.from(encodedRayLog, 'base64');

  let marketId;
  if (logData.length === 75) {
    marketId = new PublicKey(logData.subarray(43, 75));
  } else {
    throw new Error(`can't find market id in logs.`);
  }

  let initquoteLPAmount;
  let openTime;
  let initTokenAmount;

  const initPcAmountMatch = initLpLog.match(/init_pc_amount: (\d+)/);

  const initCoinAmountMatch = initLpLog.match(/init_coin_amount: (\d+)/);
  const openTimeMatch = initLpLog.match(/open_time: (\d+)/);

  if (initPcAmountMatch) {
    initquoteLPAmount = new BN(initPcAmountMatch[1]); // The first group in the regex
  }

  if (initCoinAmountMatch) {
    initTokenAmount = new BN(initCoinAmountMatch[1]); // The first group in the regex
  }

  if (openTimeMatch) {
    openTime = parseInt(openTimeMatch[1], 10);
  }

  //check if quotelpamount is in wrong order
  if (
    initquoteLPAmount &&
    initTokenAmount &&
    initquoteLPAmount.gt(initTokenAmount)
  ) {
    let temp = initquoteLPAmount;
    initquoteLPAmount = initTokenAmount;
    initTokenAmount = temp;
  }

  return {
    marketId,
    initquoteLPAmount,
    initTokenAmount,
    openTime,
  };
}
