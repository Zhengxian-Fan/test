import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { StringSession } from 'telegram/sessions';
import { TelegramClient } from 'telegram';
import { NewMessage, NewMessageEvent } from 'telegram/events';
import input from 'input';

import {
    BUY_AMOUNT_SOL,
    BUY_DELAY,
    CHECK_TOKEN_SYMBOL,
    DEFAULT_TOKEN,
    ENABLE_RUG_CHECKS,
    MAX_SOL_LP,
    MAX_TOP10_HOLDERS_PERCENTAGE,
    MIN_SOL_LP,
    MIN_SOL_REQUIRED,
    MIN_TOKEN_LP_PERCENTAGE,
    TOKEN_SYMBOL_FILTER,
    USE_PENDING_SNIPE_LIST,
    logger,
    rayFee,
    retrieveEnvVariable,
    sniperWallet,
    solanaConnection,
  } from './constants';

dotenv.config();

const apiId = parseInt(process.env.TG_API_ID, 10);
const apiHash = process.env.TG_API_HASH;
const stringSession = new StringSession(process.env.TG_SESSION_ID || '');
const pendingSnipesListLocation = path.join(__dirname, 'pending-snipe-list.txt');
const botUsername = retrieveEnvVariable('TG_BOT_USERNAME', logger);

async function start() {
    console.log('Connecting to Telegram...');
    const client = new TelegramClient(stringSession, apiId, apiHash, {
        connectionRetries: 5,
        autoReconnect: true,
        retryDelay: 1000,
    });

    await client.start({
        phoneNumber: async () => await input.text('Please enter your phone number: '),
        password: async () => await input.text('Please enter your password: '),
        phoneCode: async () => await input.text('Please enter the code you received: '),
        onError: (err) => console.error(err),
    });

    console.log('You are now connected.');
    const channelId = -1002205633867;

    try {
        const channelInfo = await client.getEntity(channelId);
        console.log(`Listening to messages from channel: ${channelInfo.title}`);

        client.addEventHandler(async (update: NewMessageEvent) => {
            const message = update.message.text;
            if (message.includes('💊CA:')) {
                const data = parseMessage(message);
                if (data.liquidityPool === 'PUMP外盘' && data.ratWalletsPercentage < 30) {
                    await addToPendingSnipeList(data.contractAddress);
                    await client.sendMessage(botUsername, {
                        message: data.contractAddress,
                      });
                }
            }
        }, new NewMessage({ chats: [channelId] }));
    } catch (error) {
        console.error('Failed to set up message handler:', error);
    }
}

function parseMessage(message) {
    const contractAddress = message.match(/💊CA:\s*`([^`]+)`/)?.[1];
    const liquidityPool = message.match(/🎯流动性池子:\s*(\S+)/)?.[1];
    const ratWalletsMatch = message.match(/🐀老鼠钱包数量:\s*\d+,\s*token占比:\s*(\d+)%/);
    const ratWalletsPercentage = ratWalletsMatch ? parseInt(ratWalletsMatch[1], 10) : null;
    return { contractAddress, liquidityPool, ratWalletsPercentage };
}

async function addToPendingSnipeList(contractAddress) {
    fs.appendFileSync(pendingSnipesListLocation, `${contractAddress}\n`, 'utf-8');
    console.log(`Added ${contractAddress} to pending snipe list.`);
}


start().catch(console.error);
