export const sniper_bot_settings = {
  buy_unit_price_fee: 200_000,
  buy_compute_limit: 200_000,
};

export const sniper_storage = {
  directoryName: 'sniper_data',
  fileName: 'bought_tokens_info.json',
};
