import inquirer from 'inquirer';
import chalk from 'chalk';
import fs from 'fs';
import { spawn } from 'child_process';

process.removeAllListeners('warning');
process.removeAllListeners('ExperimentalWarning');

async function main() {
  const ascii = fs.readFileSync('./ascii.txt', 'utf8');
  console.log('\n');
  console.log(chalk.green(ascii));
  console.log(chalk.green('Version 4.0.0'));
  console.log(chalk.green('Discord: https://discord.com/invite/47ddgNwa3b'));
  console.log(chalk.green('Docs: https://archielabs.gitbook.io/archiesniper'));
  console.log('\n');

  const npmCmd = /^win/.test(process.platform) ? 'npm.cmd' : 'npm';

  try {
    const action = await inquirer.prompt({
      type: 'list',
      name: 'action',
      message: chalk.blue(
        'Choose an action below using arrow keys and press ENTER:'
      ),
      choices: [
        { name: 'Snipe dex paid [auto buy only]', value: 'snipe' },
        { name: 'Snipe new tokens - jito [auto buy only]', value: 'snipe' },
        {
          name: 'Snipe new tokens - telegram [auto buy/sell via your tg sniper i.e. trojan]',
          value: 'snipe-tg',
        },
        {
          name: 'Snipe burns - telegram [auto buy/sell new token burns & pump fun launches via your tg sniper]',
          value: 'snipe-burns',
        },
        { name: 'Exit', value: 'exit' },
      ],
    });

    if (action.action == 'snipe') {
      const sniperNewTokens = spawn(npmCmd, ['run', 'sniper'], {
        stdio: ['inherit'],
        env: { ...process.env, FORCE_COLOR: 'true' },
        shell: true,
      });

      sniperNewTokens.stdout.on('data', (data) => {
        if (
          data
            .toString()
            .includes(
              'bigint: Failed to load bindings, pure JS will be used (try npm run rebuild?)'
            )
        ) {
          return;
        }
        console.log(`${data}`);
      });

      sniperNewTokens.stderr.on('data', (data) => {
        if (
          data
            .toString()
            .includes(
              'bigint: Failed to load bindings, pure JS will be used (try npm run rebuild?)'
            )
        ) {
          return;
        }
        console.error(`Error: ${data}`);
      });

      sniperNewTokens.on('close', (code) => {
        console.log(`sniper exited with code ${code}`);
      });
    }

    if (action.action === 'snipe-burns') {
      const hasPremiumWebhook = await inquirer.prompt({
        type: 'confirm',
        name: 'hasPremiumWebhook',
        message: 'Have you purchased premium burn webhook access?',
      });

      if (!hasPremiumWebhook.hasPremiumWebhook) {
        console.log(
          chalk.yellow(
            `Premium burn webhook access is required to use this feature.\nContact admin: 'archiesnipes' in Archie labs server: https://discord.com/invite/47ddgNwa3b to purchase subscription.`
          )
        );
        return;
      }

      const sniperBurns = spawn(npmCmd, ['run', 'sniper-burns'], {
        stdio: ['inherit'],
        env: { ...process.env, FORCE_COLOR: 'true' },
        shell: true,
      });

      sniperBurns.stdout.on('data', (data) => {
        if (
          data
            .toString()
            .includes(
              'bigint: Failed to load bindings, pure JS will be used (try npm run rebuild?)'
            )
        ) {
          return;
        }
        console.log(`${data}`);
      });

      sniperBurns.stderr.on('data', (data) => {
        if (
          data
            .toString()
            .includes(
              'bigint: Failed to load bindings, pure JS will be used (try npm run rebuild?)'
            )
        ) {
          return;
        }
        console.error(`Error: ${data}`);
      });

      sniperBurns.on('close', (code) => {
        console.log(`sniper-burns exited with code ${code}`);
      });
    }

    if (action.action === 'snipe-tg') {
      const snipeTg = spawn(npmCmd, ['run', 'sniper-tg'], {
        stdio: ['inherit'],
        env: { ...process.env, FORCE_COLOR: 'true' },
        shell: true,
      });

      snipeTg.stdout.on('data', (data) => {
        if (
          data
            .toString()
            .includes(
              'bigint: Failed to load bindings, pure JS will be used (try npm run rebuild?)'
            )
        ) {
          return;
        }
        console.log(`${data}`);
      });

      snipeTg.stderr.on('data', (data) => {
        if (
          data
            .toString()
            .includes(
              'bigint: Failed to load bindings, pure JS will be used (try npm run rebuild?)'
            )
        ) {
          return;
        }
        console.error(`Error: ${data}`);
      });

      snipeTg.on('close', (code) => {
        console.log(`sniper-tg exited with code ${code}`);
      });
    }

    if (action.action === 'exit') {
      console.log(chalk.yellow('Exiting...'));
      return;
    }
  } catch (error) {
    console.error(chalk.red(`Error occurred: ${error}`));
  }
}

main();
