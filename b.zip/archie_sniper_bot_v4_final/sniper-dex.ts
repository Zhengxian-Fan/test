import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { Connection } from '@solana/web3.js';
import input from 'input';
import readline from 'readline';

import {
  Liquidity,
  LiquidityPoolKeysV4,
  TokenAmount,
} from '@raydium-io/raydium-sdk';
import BN, { min } from 'bn.js';
import {
  checkSolBalance,
  getTokenMetadataInfo,
  initializeConfigurations,
  listenForTokenPurchase,
  logErrorToFile,
  rugCheck,
  setupSnipeListMonitoring,
  sleep,
  storeData,
} from './utils';
import base58 from 'bs58';
import {
  BUY_AMOUNT_SOL,
  BUY_DELAY,
  CHECK_TOKEN_SYMBOL,
  DEFAULT_TOKEN,
  ENABLE_RUG_CHECKS,
  MAX_SOL_LP,
  MAX_TOP10_HOLDERS_PERCENTAGE,
  MIN_SOL_LP,
  MIN_SOL_REQUIRED,
  MIN_TOKEN_LP_PERCENTAGE,
  TOKEN_SYMBOL_FILTER,
  USE_PENDING_SNIPE_LIST,
  logger,
  rayFee,
  retrieveEnvVariable,
  sniperWallet,
  solanaConnection,
} from './constants';
import { StringSession } from 'telegram/sessions';
import { TelegramClient } from 'telegram';
import { NewMessage, NewMessageEvent } from 'telegram/events';
import {
  extractMarketAndLpInfoFromLogs,
  getPoolKeysFromMarketId,
} from './swapUtils';
import chalk from 'chalk';

dotenv.config();

const tgApiId = parseInt(retrieveEnvVariable('TG_API_ID', logger), 10);
const tgApiHash = retrieveEnvVariable('TG_API_HASH', logger);
const tgSessionId = process.env.TG_SESSION_ID || '';
const tgBotUsername = retrieveEnvVariable('TG_BOT_USERNAME', logger);

/**storage */
const newDataPath = path.join(__dirname, 'sniper_data', 'bought_tokens.json');
const pendingSnipesListLocation = path.join(
  __dirname,
  'pending-snipe-list.txt'
);

const seenSignatures = new Set<string>();

let pendingSnipeList: string[] = [];

let tokenSymbolToSnipe = TOKEN_SYMBOL_FILTER.toLowerCase();

const botUsername = tgBotUsername;

const stringSession = new StringSession(tgSessionId); // fill this later with the value from session.save()

const client = new TelegramClient(stringSession, tgApiId, tgApiHash, {
  connectionRetries: 5,
  autoReconnect: true,
  retryDelay: 1000,
});

async function monitorChannelMessages() {
  try {
    await startTelegramClient();

    // Get the bot entity
    const bot = await client.getEntity(botUsername);
    const botId = bot.id;

    // Get the channel entity for DEX付款监控频道
    const channelEntity = await client.getEntity('DEX付款监控频道');
    const channelId = channelEntity.id;

    // Add an event handler to listen to new messages from the channel
    client.addEventHandler(
      async (update: NewMessageEvent) => {
        const message = update.message.text;

        // Check if the message is from the specified channel
        if (update.message.peerId.channelId?.toString() === channelId.toString()) {
          logger.info(`New message from channel 'DEX付款监控频道': ${message}`);

          // Send the message to the bot
          const response = await client.sendMessage(botUsername, {
            message: message,
          });

          logger.info(`Message forwarded to bot: ${response}`);
        }
      },
      new NewMessage({
        chats: [channelId], // Monitor the specified channel
      })
    );

    logger.info(`Monitoring messages from channel 'DEX付款监控频道'...`);
  } catch (error) {
    const timestamp = new Date().toISOString();
    const errorMessage = `Error in channel message monitor at ${timestamp}: ${error}.`;
    logger.error(errorMessage);
    logErrorToFile(errorMessage, 'errorChannelMonitorLogs.txt');
  }
}

monitorChannelMessages();

function fetchPendingSnipeList(): string[] {
  logger.info('Fetching snipe list...');
  try {
    const snipeList = fs
      .readFileSync(pendingSnipesListLocation, 'utf-8')
      .split('\n')
      .map((item) => item.trim())
      .filter((item) => item);

    logger.info(`Snipe list fetched: ${snipeList.length} tokens`);

    pendingSnipeList = snipeList;

    return snipeList;
  } catch (error) {
    const errorMessage = `Error fetching snipe list: ${error}`;
    logger.error(errorMessage);
    throw new Error(errorMessage);
  }
}

async function startTelegramClient() {
  logger.info('starting telegram client...');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  await client.start({
    phoneNumber: () =>
      new Promise((resolve) =>
        rl.question('Please enter your number (inc. country code): ', resolve)
      ),
    password: () =>
      new Promise((resolve) =>
        rl.question('Please enter your password: ', resolve)
      ),
    phoneCode: () =>
      new Promise((resolve) =>
        rl.question('Please enter the code you received in telegram: ', resolve)
      ),
    onError: (err) => console.log(err),
  });

  console.log('You should now be connected.');
  if (tgSessionId == '') {
    console.log(
      chalk.yellow(
        'Store this value in .env as TELEGRAM_SESSION_ID to avoid logging in again'
      )
    );
    console.log(client.session.save()); // Save this string to avoid logging in again
  }

  rl.close();
}
